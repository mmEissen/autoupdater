import time

if __name__ == "__main__":
    time.sleep(9999)  # some long time
